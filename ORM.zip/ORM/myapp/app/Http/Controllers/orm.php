<?php

namespace App\Http\Controllers;
use App\Models\student;
use Illuminate\Http\Request;

class orm extends Controller
{
    public function Index(){
         $select = student::all();
        return view('home',compact('select'));
       
    }

    public function OnInsert(Request $req){
        $data = new student();
        $data->name = $req->stname;
        $data->email = $req->stemail;
        $data->dept = $req->stdept;

       $insert =   $data->save();
       
       return  redirect('/');
      
    }

    public function OnDelete($id){
         $delete = student::find($id);

         $delete->delete();
         return  redirect('/');
    }

    public function OnEdit($id){
         $data = student::find($id);

         return view('edit',compact('data')) ;
    }
    public function OnUpdate(Request $req,$id){
        $data = student::find($id);
        $data->name = $req->stname;
        $data->email = $req->stemail;
        $data->dept = $req->stdept;

        $data->save();
        return  redirect('/');
    }
}
