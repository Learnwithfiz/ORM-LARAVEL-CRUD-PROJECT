<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\orm;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::get('/',[orm::class,'Index']);
Route::post('/insert',[orm::class,'OnInsert']);
Route::get('/delete/{id}',[orm::class,'OnDelete']);
Route::get('/edit/{id}',[orm::class,'OnEdit']);
Route::post('/update/{id}',[orm::class,'OnUpdate']);